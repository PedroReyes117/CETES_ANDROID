package olvera.david.calculadoracetes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.TextView
import android.widget.Toast
import olvera.david.calculadoracetes.databinding.ActivityMainBinding
import java.util.Objects

class MainActivity : AppCompatActivity() {
    //Declarar vistas
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //Conectar el hml con programacion para que obtebga datos o sea hacerlo funcionar

        binding.btnCalcular.setOnClickListener {
            //Validar que cantidad no este vacia y que plazo no sea 0
            /*var cantidad = 0.0
            if(binding.etCantidad.text.isNullOrBlank()){
                // Mostrar un Toast si los valores son inválidos
                Toast.makeText(
                    this,
                    "Por favor, Ingresa una cantidad",
                    Toast.LENGTH_SHORT
                ).show()
            }*/

        }
            var cantidad = binding.etCantidad.text.toString().toDouble()//Validar si n esta vacio
            var plazo = binding.sbPlazo.progress
            var rendimiento = calcularREndimiento(plazo, cantidad)
            binding.tvResultado.text = rendimiento.toString()

            if (cantidad == 0.0 || plazo == 0) {
                // Mostrar un Toast si los valores son inválidos
                Toast.makeText(
                    this,
                    "Valores invalidos por favor, ingrese valores válidos",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                var cantidad = cantidad.toDouble()
                var plazo = plazo.toInt()

                // Realizar el cálculo si los valores son válidos
                var rendimiento = calcularREndimiento(plazo, cantidad)
                // Mostrar el resultado en un Toast
                Toast.makeText(
                    this,
                    "El resultado del cálculo es: $rendimiento",
                    Toast.LENGTH_SHORT
                ).show()
                // Después de calcular el rendimiento
                var resultado = calcularREndimiento(plazo, cantidad)
                // Redondear el resultado a dos decimales
                resultado = (resultado * 100).toDouble().toInt() / 100.0
                // Concatenar el signo de pesos y mostrar el resultado en tvResultado
                binding.tvResultado.text = "$" + resultado.toString()
            }

        }


    }
    override fun onStart(){
        super.onStart()
        Log.d("calculadora","Estoy en onStart")
    }
    override fun onResume(){
        super.onResume()
        Log.d("calculadora","Estoy en onResume")
    }
    override fun onResume(){
        super.onResume()
        Log.d("calculadora","Estoy en onResume")
    }
   /* fun obteberCantidad():Double{
        var cantidad = 0.0
        if(binding.etCantidad.text.isNullOrBlank()){
            // Mostrar un Toast si los valores son inválidos
            Toast.makeText(
                this,
                "Por favor, Ingresa una cantidad",
                Toast.LENGTH_SHORT
            ).show()
        }else{
            var cantidad = binding.etCantidad.text.toString().toDouble()
        }
    }*/
    /*fun mostrarMensaje(mensaje:String){
        Toast.makeText(
            this,
            mensaje,
            Toast.LENGTH_SHORT
        ).show()
    }*/
    fun calcularREndimiento(plazo: Int, cantidad: Double): Double {
        val int_por_mes = (11.0 / 12.0) / 100
        Log.d("interes oir mes", int_por_mes.toString())
        val rendimiento = calcularREndimiento(plazo, cantidad)
        Log.d("rendimineto", rendimiento.toString())
        return cantidad + (int_por_mes * cantidad * plazo)
    }




